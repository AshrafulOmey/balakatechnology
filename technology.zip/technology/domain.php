<!DOCTYPE html>
<html lang="en">
  <head>
    <title>BALAKA TECHNOLOGY</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
 
 
 <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '4146244985455159');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=4146244985455159&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
 
  </head>
  <body>
      
          <!-- Messenger Chat plugin Code -->
    <div id="fb-root"></div>

    <!-- Your Chat plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "100433295553205");
      chatbox.setAttribute("attribution", "biz_inbox");

      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v11.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	     <span> <a style="color: rgb(255, 196, 86);" class="navbar-brand" href="../../index.html"> Balaka Group</a> </span>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="domain.php" class="nav-link">Domain</a></li>
	          <li class="dropdown2 nav-item"><a class="nav-link">Services</a>
            <ul class="dropdown-menu2">
              <li> <a href="web.html "> Web Development </a></li>
              <li> <a href="app.html"> App Development </a></li>
              <li> <a href="graphics.html"> Motion Graphics </a></li>
              <li> <a href="marketing.html"> Digital Marketing </a> </li>
            </ul>
            </li>
	          <li class="nav-item"><a href="blog.html" class="nav-link">Blog</a></li>
	          <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="contact.html" class="nav-link"><span>Get started</span></a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>

    <style>
      .dropdown-menu2 a {
        padding: 1em;
        margin-left: -2em;
        font-family: monospace;
        color: orange;
        font-size: 16px !important;
      }
      .dropdown-menu2 a:hover{
        color: thistle;
      }

     
      .dropdown-menu2{
        list-style: unset;
        display: none;
        position: absolute;
        background-color:grey;
        box-shadow: 2px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
      }
      .dropdown2:hover .dropdown-menu2 {display: block;transition: all 0.5s ease-in-out;}
     .dropdown-menu2 {display: none;transition: all 0.5s ease-in-out;}
      

    </style>

    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div class="slider-item bread-item" style="background-image: url(images/bg_1.jpg);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container-fluid">
          <div class="row slider-text align-items-center justify-content-center" data-scrollax-parent="true">

            <div class="col-md-8 mt-5 text-center col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
              <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html">Home</a></span> <span>Domain</span></p>
	            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Domain Hosting</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
<!-- Namecheap domain checker not working
	<section>
		<div id="PlaceToPutTable"></div>
		<iframe id="iframe" src="https://www.namecheap.com/" style="display:hidden;"></iframe>
	</section> -->

	<section class="body2">
		<div class="wrapper">
            <h2 style="margin-top: 5rem; text-align: center;">Check Domain Name Availability</h2>
            
			  <div class="container2">
                <form action="" method="GET">
                    <input id="searchBar" class="searchbar" type="text" name="domain" placeholder="Search domain name..." value="<?php if(isset($_GET['domain'])){ echo $_GET['domain']; } ?>">
                    <button type="submit" id="btnSearch" class="btn-search"><i class="fa fa-search"></i></button>
                </form>
            
		</div>
            <?php
                error_reporting(0);
                if(isset($_GET['domain'])){
                    $domain = $_GET['domain'];
                    if ( gethostbyname($domain) != $domain ) {
                        echo "<h3 class='fail'>Domain Already Registered!</h3>";
                    }
                    else {
                        echo "<h3 class='success'>Hurry, your domain is available!, you can register it.</h3>";
                    }
                }
            ?>
        </div>

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"/>
        <style type="text/css">
             h2, h3 {
                font-weight: normal;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                color: #333;
            }
            .body2 {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                height: 30vh;
            }
			
			/* h2 {
                font-size: 26px;
                text-align: center;
            }
            h3 {font-size: 24px; } */

            h3.success {
                color: #008000;
                text-align: center;
            }
            h3.fail {
                color: #ff0000;
                text-align: center;
            }
            .container2 {
                display: flex;
                flex-direction: row;
                justify-content: center;
                align-items: center;
            }
            .searchbar {
                /* padding: 6px 10px; */
                /* width: 400px; */
                max-width: 100%;
                border: none;
                margin-top: 1px;
                margin-right: 8px;
                font-size: 1em;
                border-bottom: #333 solid 2px;
                transition: 0.3s;
            }
            .searchbar::placeholder {
                font-size: 1em;
            }
            .searchbar:focus {
                outline: none;
            }
            .btn-search {
                cursor: pointer;
                text-decoration: none !important;
                font-size: 1.5em;
                padding-top: 5px;
                padding-bottom: 5px;
                background-color: transparent;
                border: none;
                outline: none;
            }
        </style>
	</section>

	<!-- <section class="ftco-domain">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-lg-5 heading-white mb-4 mb-sm-4 mb-lg-0 ftco-animate">
    				<h2>Search You Domain Name</h2>
    				 <p></p> 
    			</div>
    			<div class="col-lg-7 ftco-wrap ftco-animate">
    				<form action="#" class="domain-form d-flex">
              <div class="form-group domain-name">
                <input type="text" class="form-control name px-4" placeholder="Enter your domain name...">
              </div>
              <div class="form-group domain-select d-flex">
	              <div class="select-wrap">
                  <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                  <select name="" id="" class="form-control">
                  	<option value="">.com</option>
                    <option value="">.net</option>
                    <option value="">.info</option>
                    <option value="">.org</option>
                    <option value="">.xyz</option>
                  </select>
                </div>
                <input type="submit" class="search-domain btn btn-primary text-center" value="Search">
	            </div>
            </form>
            <p class="domain-price mt-2"><span><small>.com</small> ৳950</span> <span><small>.net</small> ৳1000</span> <span><small>.com.bd</small> ৳1900</span> <span><small>.info</small> ৳1500</span><span><small>.org</small> ৳1000</span></p>
    			</div>
    		</div>
    	</div>
    </section> -->




  
    <section class="ftco-section">
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-4">Domain Pricing</h2>
            <p>Domain prices are for 1 year. For com.bd valid documents (Trade license, NID etc) are needed and price is for 2 years. </p>
          </div>
        </div>
    		<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="table-responsive">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr>
						        <th>TLD</th>
						        <th>Duration</th>
						        <th>Registration</th>
						        <th>Renewal</th>
						        <th>Transfer</th>
						      </tr>
						    </thead>
						    <tbody>
						      <tr>
						        <td>.com</td>
						        <td>1 Year</td>
						        <td>৳850.00</td>
						        <td>৳850.00</td>
						        <td>৳850.00</td>
						      </tr>
						      <tr>
						        <td>.net</td>
						        <td>1 Year</td>
						        <td>৳950.00</td>
						        <td>৳950.00</td>
						        <td>৳950.00</td>
						        
						      </tr>
						      <tr>
						        <td>.org</td>
						        <td>1 Year</td>
						        <td>৳1000.00</td>
						        <td>৳1000.00</td>
						        <td>৳1000.00</td>
						      </tr>
						      <tr>
						        <td>.com.bd</td>
						        <td>2 Year</td>
						        <td>৳2000.00</td>
						        <td>৳2000.00</td>
						        <td>৳2000.00</td>
						      </tr>
						      <tr>
						        <td>.info</td>
						        <td>1 Year</td>
						        <td>৳1500.00</td>
						        <td>৳1500.00</td>
						        <td>৳1500.00</td>
						      </tr>
						      <tr>
						        <td>.xyz</td>
						        <td>1 Year</td>
						        <td>৳200.00</td>
						        <td>৳200.00</td>
						        <td>৳200.00</td>
						      </tr>
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
    	</div>
    </section>

    <section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-4">Your Question</h2>
            <!-- <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p> -->
          </div>
        </div>
    		<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div id="accordion">
    					<div class="row">
    						<div class="col-md-6">
    							<div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menuone" aria-expanded="true" aria-controls="menuone">What is your domain name? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menuone" class="collapse show">
						          <div class="card-body">
												<p>Name of your website. ex-www.domain.com</p>
						          </div>
						        </div>
						      </div>

						      <div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menutwo" aria-expanded="false" aria-controls="menutwo">How long is my domain name valid? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menutwo" class="collapse">
						          <div class="card-body">
												<p>1 year untill renewed.</p>
						          </div>
						        </div>
						      </div>

						      <div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menu3" aria-expanded="false" aria-controls="menu3">Can I sell my domain name? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menu3" class="collapse">
						          <div class="card-body">
												<p>Yes! If anyone wants to buy.</p>
						          </div>
						        </div>
						      </div>
    						</div>

    						<div class="col-md-6">
    							<div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menu4" aria-expanded="false" aria-controls="menu4">Can I cancel a domain? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menu4" class="collapse">
						          <div class="card-body">
												<p>Yes! But you wont get refunded.</p>
						          </div>
						        </div>
						      </div>

						      <div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menu5" aria-expanded="false" aria-controls="menu5">How do I transfer a domain name? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menu5" class="collapse">
						          <div class="card-body">
												<p>Message Us. You need to collect EPP code and unlock domain on previous domain provider's website.</p>
						          </div>
						        </div>
						      </div>

						      <div class="card">
						        <div class="card-header">
										  <a class="card-link" data-toggle="collapse"  href="#menu6" aria-expanded="false" aria-controls="menu6">How do I setup URL forwarding? <span class="collapsed"><i class="icon-plus-circle"></i></span><span class="expanded"><i class="icon-minus-circle"></i></span></a>
						        </div>
						        <div id="menu6" class="collapse">
						          <div class="card-body">
												<p>Message us. There is usually an option on domain providers website after login.</p>
						          </div>
						        </div>
						      </div>
    						</div>
    					</div>
				    </div>
    			</div>
    		</div>
    	</div>
    </section>

     <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <a  href="http://www.balakagroupbd.com"> <h2  style="color: orange;" class="ftco-heading-2">Balaka Group</h2> </a>
              <p>Balaka Group started it's journy in 1983 by the establishment of Balakatraders (PVT) limited which is one of the most renowned Custom clearing and forwarding (C&F) agent in Bangladesh. Now, We have other related services. We always believe that good service brings better clients. Our goal is to never compromise on quality.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/Balakagroupbd" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Unseful Links</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Servers</a></li>
                <li><a href="#" class="py-2 d-block">Windos Hosting</a></li>
                <li><a href="#" class="py-2 d-block">Cloud Hosting</a></li>
                <li><a href="#" class="py-2 d-block">OS Servers</a></li>
                <li><a href="#" class="py-2 d-block">Linux Servers</a></li>
                <li><a href="#" class="py-2 d-block">Policy</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Navigational</h2>
              <ul class="list-unstyled">
                <li><a href="index.html" class="py-2 d-block">Home</a></li>
                <li><a href="about.html" class="py-2 d-block">About</a></li>
                <li><a href="marketing.html" class="py-2 d-block">Digital Marketing</a></li>
                <li><a href="graphics.html" class="py-2 d-block">Motion Graphics</a></li>
                
                <li><a href="blog.html" class="py-2 d-block">Blog</a></li>
                <li><a href="contact.html" class="py-2 d-block">Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Office</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">59 Agrabad Jame Mosque Complex (2nd floor)
                    Agrabad, Chittagong.</span></li>
                    <li><span class="icon icon-map-marker"></span><span class="text">Railway Market, 1No Tejgaon Railgate,
                      Tejgaon, Dhaka.</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">(+880) 1673 440414</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">it@balakagroupbd.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Balaka Group All rights reserved | This Website is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://balakagroupbd.com" target="_blank">Balaka Technology</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>